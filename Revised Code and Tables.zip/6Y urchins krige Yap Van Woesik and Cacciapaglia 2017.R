# R van Woesik and C Cacciapaglia 2017
# 
# Keeping up with sea-level rise: carbonate production rates in Palau and Yap, western Pacific Ocean
# 
# Code to Krige erosion by urchins throughout Yap's reefs 


library(maptools)
library(sp)
library(rgdal)
library(plotGoogleMaps)
library(spatstat)
library(GISTools)
library(PBSmapping)
library(raster)

Ppts <- read_csv("E:/ACCRETION OF REEFS/Accretion Model/Yap/Yap site model.csv",col_types = cols(X1 = col_skip()))
coordinates(Ppts)<- ~palsites.x+palsites.y


setwd("E:/ACCRETION OF REEFS/YAP 2017")

#lagoon
yaplagoon1 <- readOGR(".","Yap Lagoon")
prj <- CRS('+proj=longlat +datum=WGS84')
proj4string(yaplagoon1)<-prj
plot(yaplagoon1, border="orange", axes=TRUE, las=1) # las, labels text horizontal or perpendicular to #axis

#
# reefs<-readRDS("C:/Users/Chris/Desktop/van Woesik/external HD dump/Coral Species Reef Distributions/startup/reefs.rds")
# reefs2<-crop(reefs,c(-1333304,-1311177,1045323, 1074302))
# saveRDS(reefs2,"yapreefs.rds")

#read in YAP reefs
reefs2<-readRDS("yapreefs.rds")
yaplagoon<-spTransform(yaplagoon1,proj4string(reefs2))
bbox(yaplagoon)

#outer reefs
yapouter<-l.yaplagoon <- as(yaplagoon, "SpatialLines") 
plot(yapouter, col="orange", las=1)
yapouter1<-spTransform(yapouter,prj)
#inner reefs
yapinner<-reefs2
plot(yapinner, border="lightblue",add=T)

prjlonlat<-CRS('+proj=longlat +datum=WGS84')
yapinner1<-spTransform(yapinner,prjlonlat)

compassRose<-function(x,y,rot=0,cex=1,cex.dir=1,llwd=1,col='black') { 
  oldcex<-par(cex=cex) 
  mheight<-strheight("M") 
  xylim<-par("usr") 
  plotdim<-par("pin") 
  xmult<-(xylim[2]-xylim[1])/(xylim[4]-xylim[3])*plotdim[2]/plotdim[1] 
  point.angles<-seq(0,7*pi/4,by=pi/4)+pi*rot/180 
  crspans<-rep(c(mheight*3,mheight/2),4) 
  xpoints<-cos(point.angles)*crspans*xmult+x 
  ypoints<-sin(point.angles)*crspans+y 
  polygon(xpoints,ypoints,lwd=llwd,border=col) 
  txtxpoints<-cos(point.angles[c(1,3,5,7)])*1.33*crspans[1]*xmult+x 
  txtypoints<-sin(point.angles[c(1,3,5,7)])*1.33*crspans[1]+y 
  text(txtxpoints,txtypoints,c("E","N","W","S"),cex=cex.dir,col=col) 
  par(oldcex) 
}
plot(yapouter1)
plot(yapinner1, add=T,col='lightblue')
plot(yapouter1,add=T,lwd=2)
points(Ppts,pch=16,col='red')
proj4string(Ppts)<-CRS('+proj=longlat +datum=WGS84')

library(rgdal)
library(automap)
library(gstat)

PptsO<-spTransform(Ppts, CRS("+proj=merc +zone=53s +ellps=WGS84 +datum=WGS84")) #make sure zone fits!!!!


raslistfull<-list()
maskedras<-list()
for(i in 1:3){
  PptsO
  if(i==1){Ppts<-subset(PptsO,P.locat=='outer')}
  if(i==2){Ppts<-subset(PptsO,P.locat=='patch')}
  
  #set up grid
  resg<-50
  extra<-5000
  grd <- expand.grid(x = seq(from = bbox(Ppts)[1]-extra, to = bbox(Ppts)[3]+extra, by = resg), y = seq(from = bbox(Ppts)[2]-extra, to = bbox(Ppts)[4]+extra, by = resg))
  #plot(grd,pch='.', cex = .4)
  #points(Ppts, pch = 16, col = "red", cex = 1)
  gridded(grd) = ~x+y
  
  
  proj4string(grd)<-CRS("+proj=merc +zone=53s +ellps=WGS84 +datum=WGS84")
  
  
  if(i==1){Panis<- vgm(psill=10,Nug=.5 ,"Sph", range=16000, anis= c(35, .6))} #anisotrophic krige, 40% for outer reefs, at 35 degrees
  if(i!=1){Panis<- vgm(psill=10,Nug=.5 ,"Sph", range=10000, anis= c(35, 1))} #non-anisotrophic, shorter range
  Kpannis <- krige(Ppts@data$BUj ~ 1, locations=Ppts, newdata=grd, Panis) 
  
  Kpannis<-raster(Kpannis)
  Rcoords<-coordinates(Kpannis)
  Rcoords<-SpatialPoints(Rcoords)
  proj4string(Rcoords)<-CRS("+proj=merc +zone=53s +ellps=WGS84 +datum=WGS84")
  Rcoords<-(spTransform(Rcoords,CRS=CRS('+proj=longlat +datum=WGS84')))
  
  Kpannis2<-raster(nrows=Kpannis@nrows,ncols=Kpannis@ncols)
  rasterize(Rcoords,Kpannis2)
  extent(Kpannis2)<-bbox(Rcoords)
  values(Kpannis2)<-values(Kpannis)
  
  # plot(Kpannis2)
  # plot(palaufore, border="black", axes=TRUE, las=1,lwd=3,add=T)
  # points(spTransform(Ppts,CRS('+proj=longlat +datum=WGS84')),pch=16,cex=1,col='blue')
  
  raslistfull[i]<-Kpannis
  #masking the rasters based on the shapefiels of palau
  
  if(i==1){
    Pmsk<-mask(Kpannis2,yapouter1)
    newmsk<-buffer(Pmsk,150,doEdge=TRUE)
    Pmsk1<-mask(Kpannis2,newmsk)
    maskedras[i]<-Pmsk1
    # plot(Pmsk1,maxpixels=500000,col=colorRampPalette(rev(c('blue','turquoise2', 'green','yellow','orange','red')))(200),interpolate=F,colNA='black')
    # plot(Pmsk1,maxpixels=500000,col=(rainbow(200, start=.8, end=.3)),interpolate=F)
    
    par(bg='black')
    image(Pmsk1,maxpixels=500000,col=colorRampPalette(rev(c('blue','turquoise2','green','yellow','red')))(200),zlim=c(range(values(Kpannis2),na.rm=T)),xlab='',ylab='') #, xaxs='r',yaxs = 'r',col.axis='white'
    compassRose(134.2453,7.72,col='white')
    box(col='white')
    axis(1,col='white',col.axis='white')
    axis(2,col='white',col.axis='white')
  }
  
  if(i==2){
    Pmsk2<-mask(Kpannis2,yapinner1)
    maskedras[i]<-Pmsk2
    
    image(Pmsk2,add=T,col=colorRampPalette(rev(c('blue','turquoise2','green','yellow','red')))(200),zlim=c(range(values(Kpannis2))),colorbar=F)
  }
}




library(plotrix)
ar=range(values(raslistfull[1][[1]]))
br=range(values(raslistfull[2][[1]]))
allr<-c(ar,br)
allr[allr<0]<-0
##################################################################

Pmsk1[Pmsk1<0]<-0
options(scipen=-3)
dev.off()
par(bg='black')
image(Pmsk1,maxpixels=500000,col=colorRampPalette(rev(c('blue','turquoise2','green','yellow','red')))(200),zlim=c(0,.07),xlab='',ylab='') #, xaxs='r',yaxs = 'r',col.axis='white'
compassRose(138.04,9.60,col='white')
color.legend(138.12,9.43,138.238,9.44,legend=round(seq(0,.07,length.out=5),3), rect.col=colorRampPalette((c('blue','turquoise2','green','yellow','red')))(200),cex=.8,col='white')
box(col='white')
axis(1,col='white',col.axis='white')
axis(2,col='white',col.axis='white')
image(Pmsk2,add=T,col=colorRampPalette((c('blue','turquoise2','green','yellow','red')))(200),zlim=c(0,.07),colorbar=F)
image(Pmsk1,add=T,col=colorRampPalette((c('blue','turquoise2','green','yellow','red')))(200),zlim=c(0,.07),colorbar=F)
text(138.179,9.424,'Carbonate removal by urchins',col='white')
text(138.179,9.41,'(kgCaCO3 m^2 yr^-1)',col='white')

options(scipen=5)




####
# Ppts <- read_csv("E:/ACCRETION OF REEFS/Accretion Model/Yap/Yap site model.csv",col_types = cols(X1 = col_skip()))
# coordinates(Ppts)<- ~palsites.x+palsites.y
# points(Ppts,pch=16,col='purple')
