# R van Woesik and C Cacciapaglia 2017
# 
# Keeping up with sea-level rise: carbonate production rates in Palau and Yap, western Pacific Ocean
# 
# Code to analyze models of Yap's reefs 

library(readr)
#summarize transect data
#setwd("C:/Users/Chris/Desktop/van Woesik/Palau2017/ACCRETION OF REEFS/Accretion Model")
setwd("E:/ACCRETION OF REEFS/Accretion Model/Yap")
rtd<-reef.transectdata<-read_csv("E:/ACCRETION OF REEFS/Accretion Model/Yap/Yap coral data August 9 2017 Final.csv")

library(plyr)
sumdata <- ddply(rtd, c("Site","Species"), summarise,
                 N    = length(Diff),
                 sum = sum(Diff),
                 mean   = mean(Diff),
                 sd   = sd(Diff),
                 planar.proportion=sum(Diff)/6000)

coraldata<-read.csv("E:/ACCRETION OF REEFS/Accretion Model/coraldensitypalau July 9.csv")#coral names, density measured from palau samples, weight/displacement method g/ml or g/cm^3
morphologydata2<-read.csv("E:/ACCRETION OF REEFS/Accretion Model/species model data RvW 2.csv")
morphologydata<-morphologydata2[,-1]
#convert rugostiy-class to rogosity correction values

Morphs<-unique(as.character(coraldata$Morphology))
rugosfac<-c(.1,0.138,.4,.348,1,.333,.2,1,.5,1)
Morphs.rugfac<-data.frame(Morphs,rugosfac)

extensionrates<- read_csv("E:/ACCRETION OF REEFS/Accretion Model/edited extension rates July5 2017.csv")
extensionrates<-as.data.frame(extensionrates)
rtds<-sumdata

#setup unique list to find corals
tlist<-unique(rtds$Species) #list of unique objects in transects, remove non-corals
slist<-tlist[-(grep('algae',tlist))]
slist<-slist[(grep(" ",slist))]
slist<-slist[-(grep('sponge',slist,ignore.case = TRUE))]
slist<-slist[-(grep('soft',slist))]
slist<-slist[-(grep('Sand',slist,ignore.case = TRUE))]

spplist<-sort(slist)

sites<-unique(sumdata$Site)
sites

# Set up to run through transects i to N (
# for (i in 1:length(Transect)){
#   }
GP<-numeric()
BFj<-numeric()
BUj<-numeric()
pfspeceros<-matrix(ncol=26,nrow=24)
UE<-matrix(ncol=3,nrow=24)
acprint<-matrix(ncol=128,nrow=24)
for (j in 1:(length(sites))){
  
  Dlist<-NA;extensionratematch<-NA;Densitymatch<-NA;morphologies<-NA;Lklist<-NA
  #k is the coral species
  #m is the parrotfish species
  #n is the macroeroder
  #o is the urchin species
  
  rtdsj<-subset(rtds,Site==sites[j])#subset to focus on site level
  
  
  #Equation 1 coral Carbonate Production
  #CP[k]= (Rk*(xk)) * (Dk*Lk) *10
  # CPk is the rate of carbonate production by calcifying species k (kg m-2 y-1)
  #xk is the planar proportion cover of coral species k, per site
  #Rk is the rugosity correction factor based on coral morphology
  #Dk is the skeletal density of coral species k (g cm-3)
  #Lk is the linear-extension rate of coral species k (cm y-1)
  
  ######################## START CORAL SPECIES LOOP k FOR SITE j
  CP<-numeric()
  for(k in 1:length(spplist)){
    Rk<-NA;xk<-NA;Dk<-NA;Lk<-NA;prin<-NA;erm<-NA;dm<-NA;types<-NA #reset values
    
    #match species list with subset, if species doesn't match, apply zero
    if(sum(rtdsj$Species==spplist[k])==0){
      CP[k]=0
      G_s<-unlist(strsplit(spplist[k],' '))
      Lklist[k]<-NA
    }
    if(sum(rtdsj$Species==spplist[k])>=1){ #if the species exists in the transect...
      
      G_s<-unlist(strsplit(spplist[k],' ')) #separate genus and species from the spplist[i]
      #print(G_s,justify='right')
      
      
      ############## RUGOSTIY FACTOR, Rk
      #unique(extensionrates$`growth form`) #check the rugosity correction factor for the different morphs
      #Rk<-coraldata[which(coraldata[,1]==spplist[k]),4];colnames(coraldata)[4] #rugosity
      #Rk<-as.numeric(Rk)
      Rk<-1
      
      types<-NA
      if(sum(extensionrates$genus==G_s[1]&extensionrates$species==G_s[2],na.rm=T)>0){
        types<-unique((extensionrates[which(extensionrates$genus==G_s[1]&extensionrates$species==G_s[2]),6]))
        types<-types[!is.na(types)]
        types<-types[1]
      }
      
      if(sum(coraldata$genus==G_s[1]&coraldata$species==G_s[2],na.rm=T)>0){
        types<-as.character(coraldata[which(coraldata$genus==G_s[1]&coraldata$species==G_s[2]),7])
      }
      
      if(sum(morphologydata$spplist==spplist[k])>0){
        types<-as.character(morphologydata[which(morphologydata$spplist==spplist[k]),8])
      }
      #print(paste('morphology =',types))
      if(sum(which(Morphs.rugfac==types))>0){
        Rk<-Morphs.rugfac[which(Morphs.rugfac==types),2]}
      
      #################PLANAR COVER, xk  
      #planar proportion is the 7th column. will be perfect match
      xk<-rtdsj[which(rtdsj$Species==spplist[k]),7]
      
      
      ################# DENSITY, Dk  
      #density of coral species, must match genus+species, or genus average| mean taken between two datasets, Pratchett et al., and measured density from Palau corals
      Dktally<-c() #reset blank
      #crosscheck with both datasets
      ####### species specific data
      if(sum(coraldata$genus==G_s[1]&coraldata$species==G_s[2],na.rm=T)>0){ #match in Genus&species
        Dktally[1]<-coraldata[which(coraldata$genus==G_s[1]&coraldata$species==G_s[2]),6]
        dm<-'species match'
      }
      if(sum(extensionrates$genus==G_s[1]&extensionrates$species==G_s[2],na.rm=T)>0){
        Dktally<-c(Dktally,mean(extensionrates[which(extensionrates$genus==G_s[1]&extensionrates$species==G_s[2]),7],na.rm=T))
        dm<-'species match'
      }
      if(sum(morphologydata$spplist==spplist[k])>0){ #match in Genus&species
        Dktally<-c(Dktally,morphologydata[which(morphologydata$spplist==spplist[k]),9])
        dm<-'species match'
      }
      
      ####### if no species specific data, try genus for each set:
      if(sum(Dktally,na.rm=T)<.1){
        Dktally<-(coraldata[which(coraldata$genus==G_s[1]),6])
        Dktally<-c(Dktally,extensionrates[which(extensionrates$genus==G_s[1]),7])
        dm<-'genus match'
      }
      
      
      Dktally<-unlist(Dktally)
      Dk<-mean(Dktally,na.rm=T)
      
      
      ###################### linear-extension rate, Lk
      ####### species specific data
      
      if(sum(extensionrates$genus==G_s[1]&extensionrates$species==G_s[2],na.rm=T)>0){
        Lk<-mean(extensionrates[which(extensionrates$genus==G_s[1]&extensionrates$species==G_s[2]),5],na.rm=T)
        Lk<-Lk/10 #convert from mm to cm
        erm<-'species match'
      }
      
      if(sum(morphologydata$spplist==spplist[k])>0){ #match in Genus&species
        Lk<-c(Lk,morphologydata[which(morphologydata$spplist==spplist[k]),10])
        erm<-'species match'
      }
      
      ####### if no species specific data, try genus for each set:
      if(sum(Lk,na.rm=T)==0){
        Lk<-c(Lk,mean(extensionrates[which(extensionrates$genus==G_s[1]),5],na.rm=T))
        Lk<-Lk/10 #convert from mm to cm
        erm<-'genus match'
      } 
      
      Lk<-mean(Lk,na.rm=T)
      
      Lklist[k]<-mean(Lk,na.rm=T)
    }
    
    ######## TOTALLING CORAL CARBONATE PRODUCTION    
    #print('   ',quote = FALSE)
    CP[k]= (Rk*(xk)) * (Dk*Lk) *10 ### run the equation 
    Dlist[k]<-Dk
    extensionratematch[k]<-erm
    Densitymatch[k]<-dm
    morphologies[k]<-types[1] #need to combine more and find out the most common morph? changing morph?
    
  } 
  ###########################END CORAL SPECIES LOOP k for site j
  
  cbinefull<-cbind(spplist,CP,Dlist,Lklist,extensionratematch,Densitymatch,morphologies)
  cbine<-cbinefull[!is.na(cbinefull[,2]),]
  if(length(cbine)==7){cbine<-matrix(cbine,ncol=7)}
  
  #barplot(as.numeric(cbine[,2]),names.arg = cbine[,1],las=2) #view coral carbonate production
  
  #CP[k]= (Rk*(xk)) * (Dk*Lk) *10
  # CPk is the rate of carbonate production by calcifying species k (kg m-2 y-1)
  #xk is the planar proportion cover of coral species k, per site
  #Rk is the rugosity correction factor based on coral morphology
  #Dk is the skeletal density of coral species k (g cm-3)
  #Lk is the linear-extension rate of coral species k (cm y-1)
  
  # Mass flux, 1 gram/second/square centimeter  =  10 kilogram/second/square meter,
  # x10 converts g cm y-1 to kg m-2 y-1 
  
  
  
  ######################## CORALINE ALGAE PRODUCTION
  CPt<-sum(CP,na.rm=T)#print(c(CPt,'coral carbonate production kg m-2 y-1'))
  #Coralline algae
  CA<-rtdsj[which(rtdsj$Species=='CA'),7];print(CA)
  CA<-c(CA,rtdsj[which(rtdsj$Species=='Coralline algae'),7]);print(CA)
  CA<-sum(CA,na.rm=T)
  
  CAP= 0.018*(CA)*10 #2
  #0.018 is the mean rate of carbonate production by coralline algae j for the
  #Caribbean in g cm y-1 (Perry et al. 2012) #Check out equation??
  #CA = coralline algae planar cover
  #CAP = carbonate production of coralline algae
  CAP<-sum(CAP)
  cbineCA<-rbind(cbine,c('CA',CAP,rep(NA,5)))
  pcbine<-cbineCA
  pcbine[,3]<-round(as.numeric(cbineCA[,3]),2)
  pcbine[,2]<-round(as.numeric(cbineCA[,2]),2)
  par(mar=c(10,3,1,1))
  #try(barplot(as.numeric(cbineCA[,2]),names.arg = cbineCA[,1],las=2))
  print('#######################################################################')
  print(c('site',j,sites[j]))
  print(pcbine,quote=F)
  
  #GROSS CARBONATE PRODUCTION (GPi) for all organisms per site (kg m-2 y-1)
  GP[j]= sum(CPt, CAP)
  print(paste(GP[j],'gross carbonate production'))
  
  
  acprint[j,1:length(spplist)]<-CP
  acprint[j,length(spplist)+1]<-CAP
  
  
  
  
  
  #########################################
  library(readxl)
  #Bioerosion - parrotfish, sea urchins, endolithic macroborers, endolithic microborers
  ftd<- read_excel("Yap pfish transect data july 9 2017.xlsx") #will change directory name based on island later
  ftd<-as.data.frame(ftd)
  ftd$size<-as.numeric(ftd$size)
  pfishdata<-read.csv("E:/ACCRETION OF REEFS/Accretion Model/pfishdata aug29 2017.csv") #.csv with fish species, volume of bite, sp, br
  #ftd<-fish.transectdata<-read.csv("pfish transect data.csv") #fish type and abundance at each site
  #Parrotfishes
  fspplist<-unique(ftd$species)
  ftd$size<-as.numeric(ftd$size)
  colnames(ftd)[1]<-'site.num'
  
  fsumdata <- ddply(ftd, c('site.num',"species"), summarise,
                    N    = length(size),
                    sum = sum(size),
                    mean   = mean(size),
                    sd   = sd(size))
  fsumdataj<-subset(fsumdata,'site.num'==j)
  
  ftdj<-subset(ftd,site.num==j)
  Bf<-numeric()
  for (n in 1:length(fspplist)){
    G_sF<-unlist(strsplit(fspplist[n],' '))
    fspplist[n]
    
    fsizes<-ftdj[which(ftdj$species==fspplist[n]),'size'] #sizes of species n
    sp<-1/(1+exp(-(-2.46142+0.08864*fsizes)))#scar proportion - based on size of parrotfish (Bonaldo and Bellwood, 2008) 
    
    #biterate
    reeftime<-9 #assume parrotfish spend 9hrs a day biting coral (Bonaldo and Bellwood, 2008) #hist of biterates through time. it actually is variable throughout day peaking in afternoon... could make a distribution...
    
    brc<-pfishdata[which(pfishdata$Species==G_sF[2]),5] #bite rate constant
    br<-60*abs(((4.31+brc-0.355)-(0.045*reeftime*fsizes))) #biterate based on brc and time, and size of fishes
    
    v<-exp(1.3172+.0624*fsizes)/1000 #Ong and Holland 2010
    
    ###find site specific coral density #RELATE TO FLOW RATE FOR SPECIES DENSITY, WILL INCORPORATE INTO CORALDATASHEET, or convert here, take base rate, and multiply by flow factor. using insitu density measurements for each species!!!
    
    corals.j<-rtdsj[match(cbine[,1],rtdsj[,2]),]
    totcor<-sum(corals.j$sum)
    corals.j<-cbind(corals.j,as.numeric(cbine[,3]));colnames(corals.j)[8]<-'density'
    D<-sum((corals.j$sum*corals.j$density/totcor),na.rm=T) #average density of entire site weighted by cover
    
    Bfn.all= v * sp * br * D * 365 * 0.001 #take the erosion of each individual fish in entire site
    Bf[n]= sum(Bfn.all) #find average erosion of species in all six transects
  }
  #Bfn rate of bioerosion by an individual species and size class n (g ind-1 y-1)
  # v is volume of single bite (cm3) --- size dependent
  #sp is proportion of bites leaving scars
  #br is the daily bite rate (bites d-1)
  #D is the average density of coral skeleton for the region (~ 1.67 g cm-3) #better
  #0.001 is a conversion factor converting g ind-1 yr-1 to kg ind-1 yr-1.
  
  # Calculate the bioerosion according to abundance of each fish species (Af1)
  
  #BF[n]=Bf[n]*subset(fsumdataj,species==fspplist[n])$sum# erosion *species 
  
  
  # and sum up all fishes per site
  hhh2<-cbind(fspplist,Bf)
  hhh2<-hhh2[match(fsumdataj$species,hhh2[,1]),]
  hhh2<-cbind(hhh2,fsumdataj$N)
  hhh2<-hhh2[hhh2[,1]!='NA',]
  colnames(hhh2)<-c('species','bioerosion kg yr-1 site-1','abundance')
  print(hhh2,quote=F)
  
  
  pfspeceros[j,]<-Bf
  colnames(pfspeceros)<-fspplist
  
  
  print(c(sum(Bf,na.rm=T)/(120*6*4),'site bioerosion parrotfish kg m-2 yr-1')) #total site erosion kg m-2 yr-1
  
  BFj[j]<-(sum(Bf,na.rm=T)/(120*6*4)) #120m transects, 4m wide ,6 transects per site
  
  
  
  
  ####################### URCHIN BIOEROSION
  utd<-urchin.transectdata<-read.csv("Yap urchin transect data.csv")
  utdj<-subset(utd,site==sites[j])
  uspplist<-as.character(unique(utd$species))
  
  #Bioerosion by sea urchins
  #Urchin erosion rates, with x measured in mm, which is the size of the urchin tests
  #Calculate the erosion rate (kg urchin-1 year-1) for each
  #individual urchin using one of the following equations:
  #where x is the urchins test size
  
  utdjd<-subset(utdj,species=='Diadema')
  xd <- utdjd$diameter.cm
  BD = (0.000001*xd^3.4192)*0.365 *0.57
  #plot(x,BD)
  BDt<-sum(BD)
  #From Januchowski-Hartley et al 2017
  #Diadematidae bioerosion (BD) = (0.000001*x3.4192)*0.365
  ######
  utdje<-subset(utdj,species=='Echinometra')
  xe<- utdje$diameter.cm
  BE = (0.0004*xe^1.9786)*0.365 *0.57
  #lines(x,BE,col='blue')
  BEt<-sum(BE)
  #From Januchowski-Hartley et al 2017
  #Echinometra mathaei bioerosion (BE ) = (0.0004*x1.9786)*0.365
  
  #General equation for all other bioeroding species (BG) = (0.0001*x2.323)*0.365
  utdjg<-subset(utdj,species=='other')
  xg<-utdjg$diameter.cm
  BG= (0.0001*xg^2.323)*0.365 * 0.57
  #lines(x,BG,lwd=2)
  BGt<-sum(BG)
  #From Januchowski-Hartley et al 2017
  
  #To calculate bioerosion by urchins in kg m-2 year-1, we summed the erosion rates of all individual urchins within each
  #transect (UE), and divided by the surface areas within each transect.
  #0.57 is a correction factor to account for the proporion of sediment re-ingested during grazing (Hunter 1977)
  # conversion 0.001 (g ind y-1 to kg ind y-1) 
  
  # Calculate the bioerosion according to abundance and size of each urchin
  
  uspplist2<-c("Echinometra","Diadema","other")
  uerosion<-c(BEt, BDt, BGt)
  UE[j,1]<-BEt;UE[j,2]<-BDt;UE[j,3]<-BGt;colnames(UE)<-c('echinometra', 'diadema', 'general')
  abundu<-c(nrow(utdje),nrow(utdjd),nrow(utdjg))
  hhh3<-(cbind(uspplist2,uerosion,abundu))
  colnames(hhh3)<-c("species",'erosion kg yr-1','abundance')
  print(hhh3,quote=F)
  #Sum up all urchins
  BUj[j]= sum(BDt, BEt, BGt)  # 9
  print(c(BUj[j],'total urchin site bioerosion kg yr-1'))
  
  NPj<-GP[j]-(BFj[j]+BUj[j])
  print("   ",quote=F)
  print(paste('Net= ',round(NPj,3),' = Gross ',round(GP[j],3),' - (urchin ',round(BUj[j],3),' + pfish ',round(BFj[j],3),")",sep=''))
  
  
  
} #END j SITE LOOP


#Transect Rugosity, site averaged

rugv<-ddply(rtd, c("Site"), summarise,
            sum = sum(rugosity,na.rm=T),
            mean   = mean(rugosity,na.rm=T),
            sd   = sd(rugosity,na.rm=T))


r<-10/rugv$mean
r[is.na(r)]<-1

#Sedimentation 
sed<- 0.4 #kgcaco3m2


#Bioerosion of macroborers (clinoid sponge, molluscs, polychaete worms)
#Depends on substrate avaiable
#Regional rate for Palau? assume 0.4 for now
macb.erosion.constant<-10 #Glynn 1997
macblist<-c('Cliona sponge',"Sponge encrusting",'Sponge turpois','Turpios sponge')
macb<-rtds[which((rtds[,2]%in%macblist)),] #island wide sum of macro borers.
BM<-sum(macb[,'planar.proportion'])/length(unique(rtds[,'Site']))*macb.erosion.constant #planar sum /24 sites.
#within J #BM is the regional rate of macrbioerosion (for example Whitcher 2011, St John was 0.4 kg m-2 y
#regional rate based on island wide macro prevolance?



#FINAL SUM OF ALL COMPONENTS
NP<-(GP*r)+sed-(BFj+BUj+BM)
#net production = Gross production*transect rugosity + sedimentation - parrotfish - urchin - macroborer erosion






palsites <- read.csv("E:/ACCRETION OF REEFS/Accretion Model/Yap/Yap study sites.csv")
#palsites<-palsites[order(palsites$location),]

P.locat<-c(rep('outer',10),rep('patch',14))
islandDF<-data.frame(P.locat,NP,GP,BFj,BUj,palsites$x,palsites$y)
# hist(islandDF[islandDF$P.locat=='outer',2])
# hist(islandDF[islandDF$P.locat=='inner',2])
# hist(islandDF[islandDF$P.locat=='patch',2])

#write.csv(islandDF,'Yap site model.csv')


BM
macb
BM*sum(macb[macb$Species=='Sponge encrusting',]$planar.proportion)/sum(macb$planar.proportion)
BM*sum(macb[macb$Species=='Cliona sponge',]$planar.proportion)/sum(macb$planar.proportion)
BM*sum(macb[macb$Species=='Turpios sponge',]$planar.proportion)/sum(macb$planar.proportion)




sumplot <- ddply(rtd, c("Species"), summarise,
                 sum = sum(Diff/100,na.rm=T))
sumplot2<-sumplot[rev(order(sumplot$sum)),]
dev.off()
par(mar=c(14,4,2,0))
barplot(sumplot2$sum, ylab='Yap cumulative meters',names.arg=sumplot2[,1],cex.names=.9,cex.lab=1.2,las=2,yaxt="n"); axis(2, las=3)
#sum(sumplot2$sum)# barplot(GP-BFj-BUj,add=T,names.arg=sites)

colSums(UE)

which(colnames(pfspeceros)=='NA');pfspeceros1<-pfspeceros[,c(-7,-8,-22,-26)]
par(mar=c(10,5,2,0))

colnames(pfspeceros1)<-c('Chlorurus sordidus',"Scarus dimidiatus","Scarus oviceps",'Scarus prasiognathus','Scarus niger',"Scarus flavipectoralis",'Chlorurus bleekeri',"Scarus rubroviolaceus",'Scarus spinos','Scarus schlegeli',"Scarus forsteni",'Scarus psittacus','Scarus chameleon',"Bolbometopon muricatum","Scarus altipinnus","Scarus globiceps",'Chlorurus microrhinos','Scarus frenatus','Cetoscarus bicolor',"Hipposcarus longiceps",'Chlorurus frontalis','Chlorurus japanensis')

barplot(rev(sort(colSums(pfspeceros1)))/(120*6*4), ylab=expression(paste('Yap parrotfish erosion (kgCaCO'[3],'m'^'-2','yr'^'-1',')',sep='')),names.arg=colnames(rev(sort(colSums(pfspeceros1)))),cex.names=.9,cex.lab=1.1,las=2,yaxt="n",font=3); axis(2, las=3)



acprint1<-data.frame(colSums(acprint*r,na.rm=T),row.names=c(spplist,'coralline algae'))
acprint2<-acprint1[acprint1>0]
acshrtname<-c(spplist,'coralline algae')[acprint1>0]
acprint2<-data.frame(acprint2,row.names = acshrtname)

acprint3<-rev(acprint2[order(acprint2),])
acshrtname2<-rev(acshrtname[order(acprint2)])
par(mar=c(10,5,2,0))
barplot(acprint3, ylab=expression(paste('Yap reef accretion (kgCaCO'[3],'m'^'-2','yr'^'-1',')',sep='')),names.arg=acshrtname2,cex.names=.9,cex.lab=1.1,las=2,yaxt="n",ylim=c(0,45)); axis(2, las=3)

############################
#c(rep('outer',10),rep('inner',14))
acprinta<-acprint
colnames(acprinta)<-c(spplist,'coralline algae')


acout<-acprinta[1:10,]
acout1<-data.frame(colSums(acout*r[1:10],na.rm=T),row.names=c(spplist,'coralline algae'))
acout2<-acout1[acout1>0]/10
acshrtname<-c(spplist,'coralline algae')[acout1>0]
acprint2<-data.frame(acout2,row.names = acshrtname)
acprint3<-rev(acprint2[order(acprint2),])
acshrtname2<-rev(acshrtname[order(acprint2)])
par(mar=c(10,5,2,0),mfrow=c(3,1))
barplot(acprint3, ylab=expression(paste('Yap outer reef accretion (kg CaCO'[3],' m'^'-2',' yr'^'-1',')',sep='')),names.arg=acshrtname2,cex.names=.9,cex.lab=1.1,las=2,yaxt="n",ylim=c(0,3.5)); axis(2, las=3)

acinn<-acprinta[11:24,]
acinn1<-data.frame(colSums(acinn*r[11:24],na.rm=T),row.names=c(spplist,'coralline algae'))
acinn2<-acinn1[acinn1>0]/14
acshrtname<-c(spplist,'coralline algae')[acinn1>0]
acprint2<-data.frame(acinn2,row.names = acshrtname)
acprint3<-rev(acprint2[order(acprint2),])
acshrtname2<-rev(acshrtname[order(acprint2)])
par(mar=c(10,5,2,0))
barplot(acprint3, ylab=expression(paste('Yap inner reef accretion (kg CaCO'[3],' m'^'-2',' yr'^'-1',')',sep='')),names.arg=acshrtname2,cex.names=.9,cex.lab=1.1,las=2,yaxt="n",ylim=c(0,3.5)); axis(2, las=3)



