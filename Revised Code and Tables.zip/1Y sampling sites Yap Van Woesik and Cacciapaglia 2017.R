
# R van Woesik and C Cacciapaglia
# 
# Keeping up with sea-level rise: carbonate production rates in Palau and Yap, western Pacific Ocean
# 
# Code to randomly select stratified study sites on on Yap's reefs 


library(maptools)
library(sp)
library(rgdal)
library(plotGoogleMaps)
library(spatstat)
library(GISTools)
library(PBSmapping)
library(raster)

####################################
#get shapefiles
setwd("C:/Users/Chris/Desktop/van Woesik/Palau2017/ACCRETION OF REEFS/YAP 2017")

#lagoon
yaplagoon <- readOGR(".","Yap Lagoon")
prj <- CRS('+proj=longlat +datum=WGS84')
proj4string(yaplagoon)<-prj
plot(yaplagoon, border="orange", axes=TRUE, las=1) # las, labels text horizontal or perpendicular to #axis

#
 # reefs<-readRDS("C:/Users/Chris/Desktop/van Woesik/external HD dump/Coral Species Reef Distributions/startup/reefs.rds")
 # reefs2<-crop(reefs,c(-1333304,-1311177,1045323, 1074302))
 # saveRDS(reefs2,"yapreefs.rds")

#read in YAP reefs
reefs2<-readRDS("yapreefs.rds")
yaplagoon<-spTransform(yaplagoon,proj4string(reefs2))
bbox(yaplagoon)

#outer reefs
yapouter<-l.yaplagoon <- as(yaplagoon, "SpatialLines") 
plot(yapouter, col="orange", las=1)
#inner reefs
yapinner<-reefs2
plot(yapinner, border="lightblue",add=T)

#sample

y.randomouter<- spsample(yapouter, n=10, "random")
y.randominner<- spsample(yapinner, n=14, "random")
points(y.randominner, pch=3, col='forestgreen', cex=2,lwd=2)
points(y.randomouter, pch=3, col='red', cex=2,lwd=2)

#convert to lat lon
prjlonlat<-CRS('+proj=longlat +datum=WGS84')
yapouterpts<-spTransform(y.randomouter,prjlonlat)
yapinnerpts<-spTransform(y.randominner,prjlonlat)

latlon.yap.outer<-spTransform(yapouter,prjlonlat)
latlon.yap.inner<-spTransform(yapinner,prjlonlat)



#outer
plot(latlon.yap.outer, col="orange", axes=TRUE, las=1,lwd=2) # las, labels text horizontal or perpendicular to #axis
#land
yapland<-readOGR(".","Yap Land")
plot(yapland,border='burlywood',col='burlywood',add=T)
#inner
plot(latlon.yap.inner, border="lightblue", las=1,add=T,lwd=2)

#sample, and add points
points(yapouterpts, pch=LETTERS[1:10], col='red', cex=2,lwd=2)
points(yapinnerpts, pch=LETTERS[11:24], col='blue', cex=2,lwd=2)


#Make a table:
cbind(LETTERS[1:10],yapouterpts@coords)
cbind(LETTERS[11:24],yapinnerpts@coords)



