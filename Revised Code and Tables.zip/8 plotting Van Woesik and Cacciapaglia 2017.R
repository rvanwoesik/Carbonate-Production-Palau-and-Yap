# R van Woesik and C Cacciapaglia 2017
# 
# Keeping up with sea-level rise: carbonate production rates in Palau and Yap, western Pacific Ocean
# 
# extra code for plots within Yap and Palau

library(raster)
library(rgdal)
#######call in krigged images and unite
setwd("E:/ACCRETION OF REEFS/Extrapolation via satellite/kriged RA/Palau")
pinner<-raster('inner.nc')
pouter<-raster('outer.nc')
ppatch<-raster('patch.nc')
pinner<-resample(pinner,ppatch);pouter<-resample(pouter,ppatch)
pal<-merge(ppatch,pouter,pinner)


mean(values(pal),na.rm=T)


setwd("E:/ACCRETION OF REEFS/Extrapolation via satellite/kriged RA/Yap")
yinner<-raster('inner.nc')
youter<-raster('outer.nc')
yinner<-resample(yinner,youter)
yap<-merge(youter,yinner)


mean(values(yap),na.rm=T)





compassRose<-function(x,y,rot=0,cex=1,cex.dir=1,llwd=1,col='black') { 
  oldcex<-par(cex=cex) 
  mheight<-strheight("M") 
  xylim<-par("usr") 
  plotdim<-par("pin") 
  xmult<-(xylim[2]-xylim[1])/(xylim[4]-xylim[3])*plotdim[2]/plotdim[1] 
  point.angles<-seq(0,7*pi/4,by=pi/4)+pi*rot/180 
  crspans<-rep(c(mheight*3,mheight/2),4) 
  xpoints<-cos(point.angles)*crspans*xmult+x 
  ypoints<-sin(point.angles)*crspans+y 
  polygon(xpoints,ypoints,lwd=llwd,border=col) 
  txtxpoints<-cos(point.angles[c(1,3,5,7)])*1.33*crspans[1]*xmult+x 
  txtypoints<-sin(point.angles[c(1,3,5,7)])*1.33*crspans[1]+y 
  text(txtxpoints,txtypoints,c("E","N","W","S"),cex=cex.dir,col=col) 
  par(oldcex) 
}


#65294
library(OpenStreetMap)
map <- openmap(c(7.79072,134.16234), c(7.18335,134.7),type="bing")
map$tiles[[1]]$projection@projargs<-proj4string(ppatch)
map$bbox$p1<-c(134.16234,7.79072)
map$bbox$p2<-c(134.7,7.18335)
map$tiles[[1]]$bbox$p1<-c(134.16234,7.79072)
map$tiles[[1]]$bbox$p2<-c(134.7,7.18335)

cols=colorRampPalette((c('blue','turquoise2','green','yellow','red')))(200)

#par(bg='white')
sz<-2.5
setwd("E:/ACCRETION OF REEFS/Accretion Model/Figures")
tiff('Palau reef krige.png',width=797*sz,height=900*sz, res = 300)
plot(map)
par(mar=c(0,0,0,0))
library(plotrix)
ar=range(values(pinner))
br=range(values(pouter))
cr=range(values(ppatch));allr<-c(ar,br,cr)
##################################################################
image(pinner,maxpixels=500000,col=cols,zlim=c(0,20),xlab='',ylab='',add=T) #, xaxs='r',yaxs = 'r',col.axis='white'
compassRose(134.2453,7.72,col='white')
color.legend(134.19,7.62,134.4,7.63,legend=seq(0,20,length.out=5), rect.col=cols,cex=1,col='white')

image(ppatch,add=T,col=cols,zlim=c(0,20),colorbar=F)
image(pouter,add=T,col=cols,zlim=c(0,20),colorbar=F)
text(134.295,7.609,'Net carbonate accretion',col='white')
text(134.295,7.592,expression(paste('(kg CaCO'[3],' m'^'-2',' yr'^'-1',')',sep='')),col='white')
box(lwd=3,col='white')
axis(1,tck = .015,col='white',col.axis='white',lwd=2)
axis(2,tck = .015,lwd=2,col='white',col.axis='white')
axis(3,tck = .015,lwd=2,col='white',col.axis='white')
axis(4,tck = .015,lwd=2,col='white',col.axis='white')

#mtext("134.2�E", 1, line=-1.5, adj=0.035,cex=.975,col='white')
#mtext('134.4�E',1,line=-1.5,adj=0.482,cex=.975,col='white')
#mtext('134.6�E',1,line=-1.5,adj=0.917,cex=.975,col='white')
text(134.3,7.2,"134.3�E",cex=.975,col='white')
text(134.5,7.2,'134.5�E',cex=.975,col='white')

#text(134.191,7.7,"7.7�N",cex=.975,col='white')
#mtext('7.6',2,line=-1.5,adj=0.69,cex=.975,col='white') #
#mtext("7.4", 2, line=-1.5, adj=0.349,cex=.975,col='white') #
text(134.191,7.3,'7.3�N',cex=.975,col='white')
text(134.191,7.5,'7.5�N',cex=.975,col='white')
dev.off()

















#663427
library(OpenStreetMap)
map <- openmap(c(9.7,137.993890), c(9.379406,138.249011),type="bing")
map$tiles[[1]]$projection@projargs<-proj4string(youter)
map$bbox$p1<-c(137.993890,9.7)
map$bbox$p2<-c(138.249011,9.379406)
map$tiles[[1]]$bbox$p1<-c(137.993890,9.7)
map$tiles[[1]]$bbox$p2<-c(138.249011,9.379406)

sz<-2.5
setwd("E:/ACCRETION OF REEFS/Accretion Model/Figures")
tiff('Yap reef krige.png',width=718*sz,height=900*sz, res = 300)
plot(map)
par(mar=c(0,0,0,0))

library(plotrix)
ar=range(values(yinner))
br=range(values(youter))
allr<-c(ar,br)
##################################################################

#par(bg='black')
image(youter,maxpixels=500000,col=colorRampPalette(rev(c('blue','turquoise2','green','yellow','red')))(200),zlim=c(0,20),xlab='',add=T,ylab='') #, xaxs='r',yaxs = 'r',col.axis='white'
compassRose(138.054,9.64,col='white')
color.legend(138.12,9.435,138.238,9.44,legend=seq(0,20,length.out=5), rect.col=colorRampPalette((c('blue','turquoise2','green','yellow','red')))(200),cex=1,col='white')

image(yinner,add=T,col=colorRampPalette((c('blue','turquoise2','green','yellow','red')))(200),zlim=c(0,20),colorbar=F)
image(youter,add=T,col=colorRampPalette((c('blue','turquoise2','green','yellow','red')))(200),zlim=c(0,20),colorbar=F)
text(138.179,9.429,'Net carbonate accretion',col='white')
text(138.179,9.42,expression(paste('(kg CaCO'[3],' m'^'-2',' yr'^'-1',')',sep='')),col='white')
box(lwd=3,col='white')
box(col='white')
axis(1,tck = .015,col='white',col.axis='white',lwd=2)
axis(2,tck = .015,lwd=2,col='white',col.axis='white')
axis(3,tck = .015,lwd=2,col='white',col.axis='white')
axis(4,tck = .015,lwd=2,col='white',col.axis='white')

mtext("138.05�E", 1, line=-1.5, adj=0.193,cex=.975,col='white')
mtext('138.15�E',1,line=-1.5,adj=0.62,cex=.975,col='white')

#text(138.0415,9.6507,"9.65�N", 2, cex=.975,col='white')
text(138.0415,9.5507,'9.55�N',2,cex=.975,col='white')
text(138.0415,9.4507,'9.45�N',2,cex=.975,col='white')

dev.off()
