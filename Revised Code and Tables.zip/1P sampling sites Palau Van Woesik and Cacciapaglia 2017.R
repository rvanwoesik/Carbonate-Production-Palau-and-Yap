
# R van Woesik and C Cacciapaglia
# 
# Keeping up with sea-level rise: carbonate production rates in Palau and Yap, western Pacific Ocean
# 
# Code to randomly select stratified study sites on on Palauan reefs 


#Libraries that you will need
library(maptools)
library(sp)
library(rgdal)
library(plotGoogleMaps)
library(spatstat)
library(GISTools)
library(PBSmapping)
library(raster)
library(rgeos)
####################################
#get shapefiles
#setwd("C:/RobsR/PALAU 2017/Shapefiles")
setwd("C:/Users/Chris/Desktop/van Woesik/Palau2017/ACCRETION OF REEFS/PALAU 2017/Shapefiles")
#setwd("D:/ACCRETION OF REEFS/PALAU 2017/Shapefiles")

#forereef
palaufore <- readOGR(".","fore_reefs")
prj <- CRS("+proj=utm +datum=WGS84 +zone=53 +north")
plot(palaufore, border="orange", axes=TRUE, las=1) # las, labels text horizontal or perpendicular to #axis
#inner reef
palinner <- readOGR(".","land_no babeldaob_1")
plot(palinner, border="green", axes=TRUE, las=1,add=T)
#patch reef
palpatch <- readOGR(".","patch reefs")
plot(palpatch, border="lightblue",add=T)

#convert to lat lon
prjlonlat<-CRS('+proj=longlat +datum=WGS84')
palaufore<-spTransform(palaufore,prjlonlat)
palinner<-spTransform(palinner,prjlonlat)
palpatch<-spTransform(palpatch,prjlonlat)

#crop extent and re-plot
e<-raster::`extent`(c(134.162336,134.652938,7.18335,7.790720))
palaufore<-crop(palaufore,e)
palinner<-crop(palinner,e)
palpatch<-crop(palpatch,e)

plot(palaufore, border="orange", axes=TRUE, las=1) # las, labels text horizontal or perpendicular to #axis
plot(palinner, border="green", axes=TRUE, las=1,add=T)
plot(palpatch, border="lightblue",add=T)

#sample, and add points
p.randomouter<- spsample(palaufore, n=8, "random")
p.randominner<- spsample(palinner, n=6, "random")
p.randompatch<- spsample(palpatch, n=10, "random")
points(p.randominner, pch=3, col='forestgreen', cex=2,lwd=2)
points(p.randomouter, pch=3, col='red', cex=2,lwd=2)
points(p.randompatch, pch=3, col='blue', cex=2,lwd=2)

#Make a table:
p.randomouter@coords
p.randominner@coords
p.randompatch@coords

#####################################
land<-readOGR("C:/Users/Chris/Desktop/van Woesik/Palau2017/ACCRETION OF REEFS/PALAU 2017/Shapefiles","land_no babeldaob_1")
land<-spTransform(land,prjlonlat)

setwd("C:/Users/Chris/Desktop/van Woesik/Palau2017/ACCRETION OF REEFS/Sampling")
sites<-read.csv("palausites.csv",header=F)
head(sites)
inner<-sites[9:14,2:4]
outer<-sites[1:8,2:4]
patch<-sites[15:24,2:4]


land<-crop(land,e)

 # las, labels text horizontal or perpendicular to #axis

plot(palpatch, border="lightblue",lwd=3)
plot(palaufore, border="orange", axes=TRUE, las=1,lwd=3,add=T)
plot(palinner, border="green", axes=TRUE, las=1,lwd=3,add=T)
plot(land,col='burlywood',border='burlywood',add=T)


points(inner,pch=LETTERS[9:14], col='forestgreen', cex=2,lwd=2)
points(outer,pch=LETTERS[1:8], col='red', cex=2,lwd=2)
points(patch,pch=LETTERS[15:24], col='blue', cex=2,lwd=2)





#For example 
library(rgdal)
setwd("C:/RobsR/PALAU 2017/Shapefiles")
palaufore <- readOGR(".","fore_reefs")
# note that readOGR will read the .prj file if it exists
plot(palaufore)
#To obtain the projection type:
proj4string(palaufore)

#Defining Projections           
#Bringing in the shape files with known projections
#setwd("C:/RobsR/Spatial Analysis/Palau/Shapefiles")
prj <- CRS("+proj=utm +datum=WGS84 +zone=53 +north")
#palouter <- readShapePoly("fore_reefs.shp", proj4string=prj)
#class(palouter)
#palouter is now a SpatialPolygonsDataFrame  
plot(palaufore, border="blue", axes=TRUE, las=1) # las, labels text horizontal or perpendicular to #axis

# You can also import points using
#S<- readShapePoints(".shp")
#L <- readShapeLines("..shp")
# generate a simple map showing all three layers
#plot(palouter, axes=TRUE, border="gray")
#points(pointsfile, pch=20, cex=0.8)
#lines(lines file, col="blue", lwd=2.0)


#Random sampling

#Randomly sample the outer reefs
p.randomouter<- spsample(palaufore, n=12, "random")
plot(palaufore, border="grey", axes=TRUE, las=1)
points(p.randomouter, pch=3, col='red', cex=1)

#Make a table:
p.randomouter@coords

#Regular sampling
#p.randomouter<- spsample(palouter, n=30, "regular")
#plot(palouter, border="grey", axes=TRUE, las=1)
#points(p.randomouter, pch=3, col='red', cex=1.5)

# Do the same for the patch reefs
#palpatch  <- readShapePoly("patch reefs.shp", proj4string=prj)
palpatch <- readOGR(".","patch reefs")
plot(palpatch, border="black", axes=TRUE, las=1)
#Plotting both the shape files and the points
p.randompatch<- spsample(palpatch, n=20, "random")
p.randompatch
plot(palpatch, border="grey", axes=TRUE, las=1)
points(p.randompatch, pch=3, col='red', cex=3)

p.randompatch@coords

# Do the same for the inner reefs
#setwd("C:/RobsR/Spatial Analysis/Palau/Shapefiles")
palinner <- readOGR(".","land_no babeldaob_1")
#palinner  <- readShapePoly("land_no babeldaob_1.shp", proj4string=prj)
plot(palinner, border="green", axes=TRUE, las=1)
p.randominner<- spsample(palinner, n=30, "random")
p.randominner
plot(palinner, border="green", axes=TRUE, las=1)
points(p.randominner, pch=3, col='blue', cex=1)



#Plotting 3 shapefiles together

#rm(list=ls())
library(PBSmapping)

#setwd("C:/RobsR/Spatial Analysis/Palau/Shapefiles")
prj <- CRS("+proj=utm +datum=WGS84 +zone=53 +north")
fore_reef<-importShapefile("fore_reefs.shp")
palinner  <- importShapefile("land_no babeldaob_1.shp")
palpatch  <- importShapefile("patch reefs.shp")
# note that importShapefile reads the .prj file if it exists, but it
# does not adopt the proj4 format used by the above approaches
proj.abbr <- attr(fore_reef, "projection") # abbreviated projection info
proj.full <- attr(fore_reef, "prj") # full projection info

# generate map using PBSmapping plotting functions
plotPolys(fore_reef, projection=proj.abbr, border="gray",
          xlab="Longitude", ylab="Latitude")
addPolys(palinner, border="green")
addPolys(palpatch, border="blue")


# can addPoints() or plotPoints() 
#Sampling with minimal distances
#Maybe you are interested in sampling at a minimal distance of 1 km (1000 m)
#Let's sample 10 points, with a minimal distance between the points of (1km)

library(spatstat)
Palaupoints <- rSSI(1000, 10, palaufore)
plot(Palaupoints, main="")

#check distances of points
coord <- cbind(Palaupoints$x, Palaupoints$y)
distmat <- dist(coord)
min(distmat)
hist(distmat)

TabulatePalau <- SpatialPointsDataFrame(coord, data = data.frame(id = 1:nrow(coord)))
TabulatePalau 
#Plotting attribute data

library(maptools)
library(sp)
bleach<- read.csv("c:/RobsR/Spatial Analysis/Palau/bleaching2010.csv", header=T)
bleachdf = data.frame(bleach[,1:13])
coordinates(bleachdf)<- ~x+y
bleachdf@proj4string=CRS('+proj=longlat +datum=WGS84')
bubble(bleachdf, "per_bleach", maxsize = 2.5, main = "Bleaching in Palau, 2010") 




#Now with color
b_Palau<-bubbleSP(bleachdf, zcol=c('per_bleach'),max.radius=3000, do.sqrt=FALSE)
spplot(b_Palau,'per_bleach', col.regions=colorRampPalette(c('blue','turquoise2','green','yellow','orange','red'))(200), colorkey=T)


library(plotGoogleMaps)
m<-plotGoogleMaps(b_Palau,zcol='per_bleach')



library(plotKML)
plotKML(b_Palau, col='per_bleach')

