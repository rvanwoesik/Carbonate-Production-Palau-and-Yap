# R van Woesik and C Cacciapaglia 2017
# 
# Keeping up with sea-level rise: carbonate production rates in Palau and Yap, western Pacific Ocean
# 
# Code to Krige individual parrotfish throughout Palauan reefs 


pfspeceros1<-pfspeceros/(120*6*4)


#Krige Palau carbonate
library(raster)
Ppts <- read_csv("E:/ACCRETION OF REEFS/Accretion Model/Palau/palau site model.csv",col_types = cols(X1 = col_skip()))

fspecies<-5############### bulbometopon =3; sordidus=4; dimidiatus=6; microrhinos=10; bicolor 5

Ppts<-cbind(Ppts,pfspeceros1[,fspecies])




colnames(Ppts)[8]<-'pfs'
coordinates(Ppts)<- ~palsites.lon+palsites.lat
             

setwd("C:/Users/Chris/Desktop/van Woesik/Palau2017/ACCRETION OF REEFS/PALAU 2017/Shapefiles")
#setwd("D:/ACCRETION OF REEFS/PALAU 2017/Shapefiles")
#forereef
palaufore <- readOGR(".","fore_reefs")
prj <- CRS("+proj=utm +datum=WGS84 +zone=53 +north")
#plot(palaufore, border="orange", axes=TRUE, las=1) # las, labels text horizontal or perpendicular to 
#inner reef
palinner <- readOGR(".","land_no babeldaob_1")
#plot(palinner, border="green", axes=TRUE, las=1,add=T)
#patch reef
palpatch <- readOGR(".","patch reefs")
#plot(palpatch, border="lightblue",add=T)
#convert to lat lon
prjlonlat<-CRS('+proj=longlat +datum=WGS84')
palaufore<-spTransform(palaufore,prjlonlat)
palinner<-spTransform(palinner,prjlonlat)
palpatch<-spTransform(palpatch,prjlonlat)
#crop extent and re-plot
e<-raster::`extent`(c(134.162336,134.652938,7.18335,7.790720))
palaufore<-crop(palaufore,e)
palinner<-crop(palinner,e)
palpatch<-crop(palpatch,e)
land<-readOGR("C:/Users/Chris/Desktop/van Woesik/Palau2017/ACCRETION OF REEFS/PALAU 2017/Shapefiles","land_no babeldaob_1")
land<-spTransform(land,prjlonlat)
land<-crop(land,e)
# plot(palpatch, border="lightblue",lwd=3)
# plot(palaufore, border="orange", axes=TRUE, las=1,lwd=3,add=T)
# plot(palinner, border="green", axes=TRUE, las=1,lwd=3,add=T)
# plot(land,col='burlywood',border='burlywood',add=T)
compassRose<-function(x,y,rot=0,cex=1,cex.dir=1,llwd=1,col='black') { 
  oldcex<-par(cex=cex) 
  mheight<-strheight("M") 
  xylim<-par("usr") 
  plotdim<-par("pin") 
  xmult<-(xylim[2]-xylim[1])/(xylim[4]-xylim[3])*plotdim[2]/plotdim[1] 
  point.angles<-seq(0,7*pi/4,by=pi/4)+pi*rot/180 
  crspans<-rep(c(mheight*3,mheight/2),4) 
  xpoints<-cos(point.angles)*crspans*xmult+x 
  ypoints<-sin(point.angles)*crspans+y 
  polygon(xpoints,ypoints,lwd=llwd,border=col) 
  txtxpoints<-cos(point.angles[c(1,3,5,7)])*1.33*crspans[1]*xmult+x 
  txtypoints<-sin(point.angles[c(1,3,5,7)])*1.33*crspans[1]+y 
  text(txtxpoints,txtypoints,c("E","N","W","S"),cex=cex.dir,col=col) 
  par(oldcex) 
}
points(Ppts)
proj4string(Ppts)<-CRS('+proj=longlat +datum=WGS84')

library(rgdal)
library(automap)
library(gstat)
PptsO<-spTransform(Ppts, CRS("+proj=merc +zone=53s +ellps=WGS84 +datum=WGS84")) #make sure zone fits!!!!


raslistfull<-list()
maskedras<-list()
for(i in 1:3){
  PptsO
  if(i==1){Ppts<-subset(PptsO,P.locat=='outer')}
  if(i==2){Ppts<-subset(PptsO,P.locat=='inner')}
  if(i==3){Ppts<-subset(PptsO,P.locat=='patch')}
  
  #set up grid
  resg<-100
  extra<-5000
  grd <- expand.grid(x = seq(from = bbox(Ppts)[1]-extra, to = bbox(Ppts)[3]+extra, by = resg), y = seq(from = bbox(Ppts)[2]-extra, to = bbox(Ppts)[4]+extra, by = resg))
  #plot(grd,pch='.', cex = .4)
  #points(Ppts, pch = 16, col = "red", cex = 1)
  gridded(grd) = ~x+y
  
  
  proj4string(grd)<-CRS("+proj=merc +zone=53s +ellps=WGS84 +datum=WGS84")
  
  
  if(i==1){Panis<- vgm(psill=10,Nug=.5 ,"Sph", range=16000, anis= c(35, .6))} #anisotrophic krige, 40% for outer reefs, at 35 degrees
  if(i!=1){Panis<- vgm(psill=10,Nug=.5 ,"Sph", range=10000, anis= c(35, 1))} #non-anisotrophic, shorter range
  Kpannis <- krige(Ppts@data$pfs  ~ 1, locations=Ppts, newdata=grd, Panis) 
  
  Kpannis<-raster(Kpannis)
  Rcoords<-coordinates(Kpannis)
  Rcoords<-SpatialPoints(Rcoords)
  proj4string(Rcoords)<-CRS("+proj=merc +zone=53s +ellps=WGS84 +datum=WGS84")
  Rcoords<-(spTransform(Rcoords,CRS=CRS('+proj=longlat +datum=WGS84')))
  
  Kpannis2<-raster(nrows=Kpannis@nrows,ncols=Kpannis@ncols)
  rasterize(Rcoords,Kpannis2)
  extent(Kpannis2)<-e
  values(Kpannis2)<-values(Kpannis)
  
  # plot(Kpannis2)
  # plot(palaufore, border="black", axes=TRUE, las=1,lwd=3,add=T)
  # points(spTransform(Ppts,CRS('+proj=longlat +datum=WGS84')),pch=16,cex=1,col='blue')
  
  raslistfull[i]<-Kpannis
  #masking the rasters based on the shapefiels of palau
  
  if(i==1){
    Pmsk<-mask(Kpannis2,palaufore)
    newmsk<-buffer(Pmsk,350,doEdge=TRUE)
    Pmsk1<-mask(Kpannis2,newmsk)
    maskedras[i]<-Pmsk1
    # plot(Pmsk1,maxpixels=500000,col=colorRampPalette(rev(c('blue','turquoise2', 'green','yellow','orange','red')))(200),interpolate=F,colNA='black')
    # plot(Pmsk1,maxpixels=500000,col=(rainbow(200, start=.8, end=.3)),interpolate=F)
    
    par(bg='black')
    image(Pmsk1,maxpixels=500000,col=colorRampPalette(rev(c('blue','turquoise2','green','yellow','red')))(200),zlim=c(range(values(Kpannis2),na.rm=T)),xlab='',ylab='') #, xaxs='r',yaxs = 'r',col.axis='white'
    compassRose(134.2453,7.72,col='white')
    box(col='white')
    axis(1,col='white',col.axis='white')
    axis(2,col='white',col.axis='white')
  }
  
  if(i==2){
    Pmsk2<-mask(Kpannis2,palinner)
    maskedras[i]<-Pmsk2
    
    image(Pmsk2,add=T,col=colorRampPalette(rev(c('blue','turquoise2','green','yellow','red')))(200),zlim=c(range(values(Kpannis2))),colorbar=F)
  }
  
  if(i==3){
    Pmsk<-mask(Kpannis2,palpatch)
    newmsk<-buffer(Pmsk,200,doEdge=TRUE)
    Pmsk3<-mask(Kpannis2,newmsk)
    maskedras[i]<-Pmsk3
    
    image(Pmsk3,add=T,col=colorRampPalette(rev(c('blue','turquoise2','green','yellow','red')))(200),zlim=c(range(values(Kpannis2))),colorbar=F)
  }  
  
}

# 
# options(scipen=-3)
# dev.off()
# par(bg='black')
# library(plotrix)
# ar=range(values(raslistfull[1][[1]]))
# br=range(values(raslistfull[2][[1]]))
# cr=range(values(raslistfull[3][[1]]));allr<-c(ar,br,cr)
# ##################################################################
# image(Pmsk1,maxpixels=500000,col=colorRampPalette((c('blue','turquoise2','green','yellow','red')))(200),zlim=c(0,4),xlab='',ylab='') #, xaxs='r',yaxs = 'r',col.axis='white'
# compassRose(134.2453,7.72,col='white')
# color.legend(134.19,7.62,134.4,7.63,legend=round(seq(0,4,length.out=6),3), rect.col=colorRampPalette((c('blue','turquoise2','green','yellow','red')))(200),cex=1,col='white')
# box(col='white')
# axis(1,col='white',col.axis='white')
# axis(2,col='white',col.axis='white')
# image(Pmsk2,add=T,col=colorRampPalette((c('blue','turquoise2','green','yellow','red')))(200),zlim=c(0,4),colorbar=F)
# image(Pmsk3,add=T,col=colorRampPalette((c('blue','turquoise2','green','yellow','red')))(200),zlim=c(0,4),colorbar=F)
# text(134.295,7.609,'Carbonate removal by parrotfish',col='white')
# text(134.295,7.592,'(kgCaCO3 m^2 yr^-1)',col='white')
# 
# options(scipen=5)


options(scipen=-4)
dev.off()
par(bg='black')
library(plotrix)
ar=range(values(raslistfull[1][[1]]))
br=range(values(raslistfull[2][[1]]))
cr=range(values(raslistfull[3][[1]]));allr<-c(ar,br,cr)
allr[allr<0]<-0
Pmsk1[Pmsk1<0]<-0
Pmsk2[Pmsk2<0]<-0
Pmsk3[Pmsk3<0]<-0

##################################################################
image(Pmsk1,maxpixels=500000,col=colorRampPalette((c('blue','turquoise2','green','yellow','red')))(200),zlim=c(range(allr,na.rm=T)),xlab='',ylab='') #, xaxs='r',yaxs = 'r',col.axis='white'
compassRose(134.2453,7.72,col='white')
color.legend(134.19,7.62,134.4,7.63,legend=round(seq(range(allr,na.rm=T)[1],range(allr,na.rm=T)[2],length.out=5),3), rect.col=colorRampPalette((c('blue','turquoise2','green','yellow','red')))(200),cex=1,col='white')
box(col='white')
axis(1,col='white',col.axis='white')
axis(2,col='white',col.axis='white')
image(Pmsk2,add=T,col=colorRampPalette((c('blue','turquoise2','green','yellow','red')))(200),zlim=c(range(allr,na.rm=T)),colorbar=F)
image(Pmsk3,add=T,col=colorRampPalette((c('blue','turquoise2','green','yellow','red')))(200),zlim=c(range(allr,na.rm=T)),colorbar=F)
text(134.295,7.609,paste('Carbonate removal by',colnames(pfspeceros1)[fspecies]),col='white')
text(134.295,7.592,'(kgCaCO3 m^2 yr^-1)',col='white')

options(scipen=5)


library(OpenStreetMap)
map <- openmap(c(7.79072,134.16234), c(7.18335,134.7),type="bing")#65294
map$tiles[[1]]$projection@projargs<-proj4string(ppatch)
map$bbox$p1<-c(134.16234,7.79072)
map$bbox$p2<-c(134.7,7.18335)
map$tiles[[1]]$bbox$p1<-c(134.16234,7.79072)
map$tiles[[1]]$bbox$p2<-c(134.7,7.18335)


pouter<-Pmsk1
pinner<-Pmsk2
ppatch<-Pmsk3
cols=colorRampPalette((c('blue','turquoise2','green','yellow','red')))(200)
sz<-2.5
setwd("E:/ACCRETION OF REEFS/Accretion Model/Figures/indiv fish krig")
tiff(paste('Palau',colnames(pfspeceros1)[fspecies],'krige.png'),width=797*sz,height=900*sz, res = 300)
plot(map)
par(mar=c(0,0,0,0))
library(plotrix)
ar=range(values(pinner),na.rm=T)
br=range(values(pouter),na.rm=T)
cr=range(values(ppatch),na.rm=T);allr<-c(ar,br,cr)
##################################################################
image(pinner,maxpixels=500000,col=cols,zlim=c(range(allr,na.rm=T)),xlab='',ylab='',add=T) #, xaxs='r',yaxs = 'r',col.axis='white'
compassRose(134.2453,7.72,col='white')
color.legend(134.19,7.62,134.4,7.63,legend=round(seq(range(allr)[1],range(allr)[2],length.out=5),3), rect.col=cols,cex=1,col='white')
image(ppatch,add=T,col=cols,zlim=c(range(allr,na.rm=T)),colorbar=F)
image(pouter,add=T,col=cols,zlim=c(range(allr,na.rm=T)),colorbar=F)

text(134.295,7.609,paste('Carbonate removal by',colnames(pfspeceros1)[fspecies]),col='white')
text(134.295,7.592,expression(paste('(kg CaCO'[3],' m'^'-2',' yr'^'-1',')',sep='')),col='white')
box(lwd=3,col='white')
axis(1,tck = .015,col='white',col.axis='white',lwd=2)
axis(2,tck = .015,lwd=2,col='white',col.axis='white')
axis(3,tck = .015,lwd=2,col='white',col.axis='white')
axis(4,tck = .015,lwd=2,col='white',col.axis='white')

#mtext("134.2�E", 1, line=-1.5, adj=0.035,cex=.975,col='white')
#mtext('134.4�E',1,line=-1.5,adj=0.482,cex=.975,col='white')
#mtext('134.6�E',1,line=-1.5,adj=0.917,cex=.975,col='white')
text(134.3,7.2,"134.3�E",cex=.975,col='white')
text(134.5,7.2,'134.5�E',cex=.975,col='white')

#text(134.191,7.7,"7.7�N",cex=.975,col='white')
#mtext('7.6',2,line=-1.5,adj=0.69,cex=.975,col='white') #
#mtext("7.4", 2, line=-1.5, adj=0.349,cex=.975,col='white') #
text(134.191,7.3,'7.3�N',cex=.975,col='white')
text(134.191,7.5,'7.5�N',cex=.975,col='white')
dev.off()

